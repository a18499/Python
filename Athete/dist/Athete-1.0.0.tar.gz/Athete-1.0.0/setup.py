from distutils.core import setup


setup(
	name         = 'Athete',
	version      = '1.0.0',
    py_modules   = ['Athete'],
    author       = 'Peter',
    author_email = 'a184999@gmail.com',
    description  = 'A class for athlete',
)
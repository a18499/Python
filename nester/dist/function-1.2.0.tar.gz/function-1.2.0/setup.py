from distutils.core import setup


setup(
	name         = 'function',
	version      = '1.2.0',
    py_modules   = ['function'],
    author       = 'Peter',
    author_email = 'a184999@gmail.com',
    description  = 'A simple nest list',
)

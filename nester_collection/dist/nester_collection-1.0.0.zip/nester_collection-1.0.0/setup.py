from distutils.core import setup

setup(
        name         = 'nester_collection',
        version      = '1.0.0',
        py_modules   = ['nester_list'],
        author       = 'robert',
        author_email = 'robert18499@hotmail.com',      
        url          = 'http://www.headfirstlabs.com',
        description  = 'A simple printer of nested lists',
)

from distutils.core import setup


setup(
	name         = 'time_string',
	version      = '1.0.0',
    py_modules   = ['time_string'],
    author       = 'Peter',
    author_email = 'a184999@gmail.com',
    description  = 'A function can process string',
)